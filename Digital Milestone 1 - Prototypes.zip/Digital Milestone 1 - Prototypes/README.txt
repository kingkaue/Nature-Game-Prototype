In the main menu you choose to see the art ot gameplay prototype

The art prototype has all the art assets and you can move the camera around to see them better

In the gameplay prototype:
- Pressing E on the notebook on the ground makes it change colors
- The box on the ground can be grabbed with E and placed on the red square by pressing E again
- The blue sphere can be grabbed and when touched to the cube, will cause it to turn green and get bigger
- Walking next to the capsule will make the camera switch to a dialogue mode.
  - Press E to begin the dialogue and press space to continue it
  - There is a choice option to click as well
- There is a plane with a cube that shows the mechanics of how animals will work
- On the top left of the screen there is a spirit gauge
  - Press O to increase the gauge and P to decrease

Press Escape in the gameplay or art scene to return to the main menu

Press f5 to save game and f9 to load data
